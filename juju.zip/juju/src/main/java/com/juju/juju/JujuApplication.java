package com.juju.juju;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JujuApplication {

	public static void main(String[] args) {
		SpringApplication.run(JujuApplication.class, args);
	}
}
